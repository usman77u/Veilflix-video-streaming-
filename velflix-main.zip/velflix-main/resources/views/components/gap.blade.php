<div class="h-3 w-full" style="background-color: #222"></div>
